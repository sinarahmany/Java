package com.company;

public abstract class Shape {
    //defining methods we will override them later in cylinder class
    public abstract double volume();
    public abstract double surface();


}
